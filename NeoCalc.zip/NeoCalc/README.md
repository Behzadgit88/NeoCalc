# NeoCalc

A modern Android Calculator app with dark/light theme support.

## How to build
Push to GitHub and the Actions will build the APK automatically.
